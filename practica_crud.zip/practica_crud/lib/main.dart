import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as path;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Registro de Usuarios',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          filled: true,
          fillColor: Colors.grey[50],
        ),
      ),
      home: const UserRegistrationScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
} // fin dela clase MyApp

// --- User Model ---
class User {
  int? id;
  final String nombres;
  final String correo;
  final int edad;
  final String telefono;
  final String genero;
  final DateTime fechaRegistro;

  User({
    this.id,
    required this.nombres,
    required this.correo,
    required this.edad,
    required this.telefono,
    required this.genero,
    required this.fechaRegistro,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nombres': nombres,
      'correo': correo,
      'edad': edad,
      'telefono': telefono,
      'genero': genero,
      // Store DateTime as ISO 8601 string for sqflite
      'fechaRegistro': fechaRegistro.toIso8601String(),
    };
  }

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      id: map['id'],
      nombres: map['nombres'],
      correo: map['correo'],
      edad: map['edad'],
      telefono: map['telefono'],
      genero: map['genero'],
      // Parse the stored string back to DateTime
      fechaRegistro: DateTime.parse(map['fechaRegistro']),
    );
  }
} //fin de la clase User

// --- Database Helper Class (CRUD Operations) ---
class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  static Database? _database;

  DatabaseHelper._internal();

  factory DatabaseHelper() => _instance;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final databasesPath = await getDatabasesPath();
    final dbPath = path.join(databasesPath, 'users_database.db');

    return await openDatabase(
      dbPath,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombres TEXT NOT NULL,
        correo TEXT NOT NULL,
        edad INTEGER NOT NULL,
        telefono TEXT NOT NULL,
        genero TEXT NOT NULL,
        fechaRegistro TEXT NOT NULL
      )
    ''');
  }

  // Create (C)
  Future<int> insertUser(User user) async {
    final db = await database;
    return await db.insert('users', user.toMap());
  }

  // Read (R)
  Future<List<User>> getUsers() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('users', orderBy: 'id DESC'); // Show newest first
    return List.generate(maps.length, (i) {
      return User.fromMap(maps[i]);
    });
  }

  // Update (U)
  Future<int> updateUser(User user) async {
    final db = await database;
    return await db.update(
      'users',
      user.toMap(),
      where: 'id = ?',
      whereArgs: [user.id],
    );
  }

  // Delete (D)
  Future<int> deleteUser(int id) async {
    final db = await database;
    return await db.delete(
      'users',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
} //fin de la clase Base de datos

// --- User Interface (Widget) ---
class UserRegistrationScreen extends StatefulWidget {
  const UserRegistrationScreen({super.key});

  @override
  _UserRegistrationScreenState createState() => _UserRegistrationScreenState();
}

class _UserRegistrationScreenState extends State<UserRegistrationScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final DatabaseHelper _dbHelper = DatabaseHelper();
  List<User> _users = [];

  // Controllers
  final TextEditingController _nombresController = TextEditingController();
  final TextEditingController _correoController = TextEditingController();
  final TextEditingController _edadController = TextEditingController();
  final TextEditingController _telefonoController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController(); // Not saved, but used for initial validation

  String _genero = 'Masculino';
  bool _aceptoTerminos = false;
  bool _isEditing = false;
  int? _editingUserId;

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  // Load all users from the database
  Future<void> _loadUsers() async {
    try {
      List<User> users = await _dbHelper.getUsers();
      setState(() {
        _users = users;
      });
    } catch (e) {
      // ignore: avoid_print
      print('Error loading users: $e');
    }
  }

  // Populate form fields for editing
  void _editUser(User user) {
    setState(() {
      _isEditing = true;
      _editingUserId = user.id;
      _nombresController.text = user.nombres;
      _correoController.text = user.correo;
      _edadController.text = user.edad.toString();
      _telefonoController.text = user.telefono;
      _genero = user.genero;
      // We assume terms are accepted when editing a saved user
      _aceptoTerminos = true;
    });

    // Scroll to the form
    Scrollable.ensureVisible(_formKey.currentContext!, duration: const Duration(milliseconds: 300));
  }

  // Reset all form fields and state
  void _clearForm() {
    _formKey.currentState?.reset();
    setState(() {
      _isEditing = false;
      _editingUserId = null;
      _nombresController.clear();
      _correoController.clear();
      _edadController.clear();
      _telefonoController.clear();
      _passwordController.clear();
      _genero = 'Masculino';
      _aceptoTerminos = false;
    });
  }

  // Delete user with confirmation dialog
  Future<void> _deleteUser(int id) async {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Confirmar eliminación'),
          content: const Text('¿Está seguro de que desea eliminar este usuario?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Cancelar'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.of(dialogContext).pop();
                try {
                  await _dbHelper.deleteUser(id);
                  _loadUsers();
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Usuario eliminado exitosamente 🗑️'),
                        backgroundColor: Colors.green,
                      ),
                    );
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Error al eliminar usuario: $e'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                }
              },
              child: const Text('Eliminar', style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }

  // Widget to display user information in a card
  Widget _buildUserCard(User user) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    user.nombres,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit, size: 20, color: Colors.orange),
                      onPressed: () => _editUser(user),
                      tooltip: 'Editar',
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, size: 20, color: Colors.red),
                      onPressed: () => _deleteUser(user.id!),
                      tooltip: 'Eliminar',
                    ),
                  ],
                ),
              ],
            ),
            const Divider(height: 16, color: Colors.grey),
            _buildInfoRow('✉️', user.correo),
            _buildInfoRow('🎂', 'Edad: ${user.edad} años'),
            _buildInfoRow('📞', user.telefono),
            _buildInfoRow('👤', 'Género: ${user.genero}'),
            _buildInfoRow('📅', 'Registrado: ${DateFormat('dd/MM/yyyy HH:mm').format(user.fechaRegistro)}'),
          ],
        ),
      ),
    );
  }

  // Helper widget for card rows
  Widget _buildInfoRow(String emoji, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 16)),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 14),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  // Main UI build method
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Editar Usuario' : 'Registro de Usuarios'),
        centerTitle: true,
        elevation: 4,
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          // Form Section
          Expanded(
            flex: 2,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              _isEditing ? 'Editar Usuario' : 'Formulario de Registro',
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.blueGrey,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 20),
                            // Nombres Field
                            TextFormField(
                              controller: _nombresController,
                              decoration: const InputDecoration(
                                labelText: 'Nombres Completos',
                                prefixIcon: Icon(Icons.person),
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Por favor ingrese sus nombres';
                                }
                                if (value.length < 3) {
                                  return 'Los nombres deben tener al menos 3 caracteres';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 15),
                            // Correo Field
                            TextFormField(
                              controller: _correoController,
                              decoration: const InputDecoration(
                                labelText: 'Correo Electrónico',
                                prefixIcon: Icon(Icons.email),
                              ),
                              keyboardType: TextInputType.emailAddress,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Por favor ingrese su correo';
                                }
                                if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                                    .hasMatch(value)) {
                                  return 'Por favor ingrese un correo válido';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 15),
                            // Edad Field
                            TextFormField(
                              controller: _edadController,
                              decoration: const InputDecoration(
                                labelText: 'Edad',
                                prefixIcon: Icon(Icons.cake),
                              ),
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Por favor ingrese su edad';
                                }
                                final edad = int.tryParse(value);
                                if (edad == null || edad < 1 || edad > 120) {
                                  return 'Por favor ingrese una edad válida';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 15),
                            // Teléfono Field
                            TextFormField(
                              controller: _telefonoController,
                              decoration: const InputDecoration(
                                labelText: 'Teléfono',
                                prefixIcon: Icon(Icons.phone),
                              ),
                              keyboardType: TextInputType.phone,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Por favor ingrese su teléfono';
                                }
                                if (value.length < 7) {
                                  return 'El teléfono debe tener al menos 7 dígitos';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 15),
                            // Password Field (Only for Registration)
                            if (!_isEditing)
                              TextFormField(
                                controller: _passwordController,
                                decoration: const InputDecoration(
                                  labelText: 'Contraseña',
                                  prefixIcon: Icon(Icons.lock),
                                  suffixIcon: Icon(Icons.visibility_off),
                                ),
                                obscureText: true,
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Por favor ingrese una contraseña';
                                  }
                                  if (value.length < 6) {
                                    return 'La contraseña debe tener al menos 6 caracteres';
                                  }
                                  return null;
                                },
                              ),
                            if (!_isEditing) const SizedBox(height: 15),
                            // Genero Radio Buttons
                            const Text(
                              'Género:',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                            ),
                            Row(
                              children: [
                                Radio<String>(
                                  value: 'Masculino',
                                  groupValue: _genero,
                                  onChanged: (value) {
                                    setState(() {
                                      _genero = value!;
                                    });
                                  },
                                ),
                                const Text('Masculino'),
                                Radio<String>(
                                  value: 'Femenino',
                                  groupValue: _genero,
                                  onChanged: (value) {
                                    setState(() {
                                      _genero = value!;
                                    });
                                  },
                                ),
                                const Text('Femenino'),
                              ],
                            ),
                            const SizedBox(height: 15),
                            // Terms Checkbox
                            Row(
                              children: [
                                Checkbox(
                                  value: _aceptoTerminos,
                                  onChanged: (value) {
                                    setState(() {
                                      _aceptoTerminos = value!;
                                    });
                                  },
                                ),
                                const Expanded(
                                  child: Text('Acepto los términos y condiciones'),
                                ),
                              ],
                            ),
                            const SizedBox(height: 20),
                            // Submit Button (Register or Update)
                            ElevatedButton(
                              onPressed: () async {
                                if (_formKey.currentState!.validate() && _aceptoTerminos) {
                                  try {
                                    final user = User(
                                      id: _editingUserId,
                                      nombres: _nombresController.text,
                                      correo: _correoController.text,
                                      edad: int.parse(_edadController.text),
                                      telefono: _telefonoController.text,
                                      genero: _genero,
                                      // Preserve original date on update, use now on create
                                      fechaRegistro: _isEditing
                                          ? _users.firstWhere((u) => u.id == _editingUserId!).fechaRegistro
                                          : DateTime.now(),
                                    );

                                    if (_isEditing) {
                                      await _dbHelper.updateUser(user);
                                      // ignore: use_build_context_synchronously
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(
                                          content: Text('Usuario actualizado exitosamente 🎉'),
                                          backgroundColor: Colors.green,
                                        ),
                                      );
                                    } else {
                                      await _dbHelper.insertUser(user);
                                      // ignore: use_build_context_synchronously
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(
                                          content: Text('Usuario registrado exitosamente ✅'),
                                          backgroundColor: Colors.green,
                                        ),
                                      );
                                    }

                                    _clearForm();
                                    _loadUsers();
                                  } catch (e) {
                                    // ignore: use_build_context_synchronously
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text('Error en la operación: $e'),
                                        backgroundColor: Colors.red,
                                      ),
                                    );
                                  }
                                } else if (!_aceptoTerminos) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('Debe aceptar los términos y condiciones 🛑'),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _isEditing ? Colors.orange : Colors.blue,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: Text(
                                _isEditing ? 'Actualizar Usuario' : 'Registrar Usuario',
                                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  // Cancel Edit Button outside the card
                  if (_isEditing)
                    TextButton(
                      onPressed: _clearForm,
                      child: const Text('Cancelar edición', style: TextStyle(color: Colors.red)),
                    ),
                ],
              ),
            ),
          ),

          // Users List Section
         // ...
          // Users List Section
          if (_users.isNotEmpty) ...[
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Text(
                'Usuarios Registrados',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: ListView.builder(
                itemCount: _users.length,
                itemBuilder: (context, index) {
                  return _buildUserCard(_users[index]);
                },
              ),
            ),
          ] else // <-- ¡Sin corchetes aquí! Devuelve directamente el Widget.
            const Expanded(
              flex: 3,
              child: Center(
                child: Text(
                  'Aún no hay usuarios registrados. ¡Empieza a registrar!',
                  style: TextStyle(fontSize: 16, color: Colors.grey),
                  textAlign: TextAlign.center,
                ),
              ),
            ), // <-- ¡Sin coma aquí!
        ],
      ),
    );
  }
  @override
  void dispose() {
    _nombresController.dispose();
    _correoController.dispose();
    _edadController.dispose();
    _telefonoController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}
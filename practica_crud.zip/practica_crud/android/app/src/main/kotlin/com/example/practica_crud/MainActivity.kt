package com.example.practica_crud

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
